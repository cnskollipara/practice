package com.isecurities.feecalculator.bean;

public enum TxnType {
    BUY, SELL, WITHDRAW, DEPOSIT
}

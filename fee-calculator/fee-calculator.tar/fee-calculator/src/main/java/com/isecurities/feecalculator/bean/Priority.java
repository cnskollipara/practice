package com.isecurities.feecalculator.bean;

public enum Priority {
    Y, N
}
